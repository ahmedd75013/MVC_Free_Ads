SELECT id_salle AS "Numero des salles", nom_salle AS "Nom des salles" FROM salle WHERE nbr_siege > 200 and not etage_salle = 0;
